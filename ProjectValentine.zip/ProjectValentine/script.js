// script.js
const PERSON_NAME = "bby💘";

const title = document.getElementById('title');
const result = document.getElementById('result');
const noBtn = document.getElementById('noBtn');
const yesBtn = document.getElementById('yesBtn');
const btnArea = document.getElementById('btnArea');
const hearts = document.getElementById('hearts');

function rand(min, max){ return Math.random() * (max - min) + min; }

function moveNoButton(){
  const areaRect = btnArea.getBoundingClientRect();
  const noRect = noBtn.getBoundingClientRect();
  const yesRect = yesBtn.getBoundingClientRect();

  const padding = 8;

  // limites onde o "Não" pode ficar (dentro da área)
  const maxX = areaRect.width - noRect.width - padding;
  const maxY = areaRect.height - noRect.height - padding;

  // coordenadas do "Sim" relativas à área
  const yesX = yesRect.left - areaRect.left;
  const yesY = yesRect.top  - areaRect.top;

  // "zona proibida" (um retângulo maior à volta do Sim)
  const safe = 12; // distância extra
  const forbidden = {
    left:   yesX - noRect.width - safe,
    right:  yesX + yesRect.width + safe,
    top:    yesY - noRect.height - safe,
    bottom: yesY + yesRect.height + safe
  };

  // tenta várias vezes até encontrar uma posição fora da zona proibida
  for (let i = 0; i < 60; i++){
    const x = Math.max(padding, Math.min(maxX, rand(padding, maxX)));
    const y = Math.max(padding, Math.min(maxY, rand(padding, maxY)));

    const overlapsForbidden =
      x > forbidden.left &&
      x < forbidden.right &&
      y > forbidden.top &&
      y < forbidden.bottom;

    if (!overlapsForbidden){
      noBtn.style.left = x + 'px';
      noBtn.style.top  = y + 'px';
      return;
    }
  }

  // fallback (se não conseguir, mete no canto)
  noBtn.style.left = padding + 'px';
  noBtn.style.top  = padding + 'px';
}


// Fogem ao rato
noBtn.addEventListener('mouseenter', moveNoButton);
noBtn.addEventListener('mousemove', moveNoButton);

// Fogem no telemóvel (quando tentam tocar)
noBtn.addEventListener('touchstart', (e) => {
  e.preventDefault();
  moveNoButton();
}, { passive:false });

function burstHearts(){
  for(let i=0;i<18;i++){
    const el = document.createElement('div');
    el.className = 'heart';
    el.textContent = ['💖','💘','💕','💞','💗'][Math.floor(Math.random()*5)];
    el.style.left = rand(5, 95) + 'vw';
    el.style.bottom = '-5vh';
    const dur = rand(2.2, 4.2);
    el.style.animationDuration = dur + 's';
    el.style.fontSize = rand(18, 34) + 'px';
    hearts.appendChild(el);
    setTimeout(() => el.remove(), dur * 1000);
  }
}

yesBtn.addEventListener('click', () => {
  result.textContent = `Awwwwwww ${PERSON_NAME}! Agora és oficialmente a minha Valentine 😉💞`;

  burstHearts();
  noBtn.style.opacity = 0.2;
  noBtn.style.pointerEvents = 'none';
  yesBtn.textContent = ' tudo calculado pelo pai!! 💞';
});

// posição inicial + resize
moveNoButton();
window.addEventListener('resize', moveNoButton);


// slide

const slides = document.querySelectorAll('.bg-slide');
let idx = 0;

setInterval(() => {
  slides[idx].classList.remove('active');
  idx = (idx + 1) % slides.length;
  slides[idx].classList.add('active');
}, 4500); // troca a cada 4.5s
